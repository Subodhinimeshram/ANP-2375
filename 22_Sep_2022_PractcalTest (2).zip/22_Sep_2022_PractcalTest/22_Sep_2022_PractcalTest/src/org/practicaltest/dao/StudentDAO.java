package org.practicaltest.dao;
import java.util.TreeSet;
import org.practicaltest.model.Student;
import org.practicaltest.view.StudentView;

import java.util.HashSet;
import java.util.TreeSet;

public class StudentDAO
{
	
	public static boolean AddStudentInfo(Student stu)
	{
		boolean result = false;
      	TreeSet <Student> treeSet=new TreeSet<>();
			treeSet.add(stu);
			System.out.println(treeSet);
		  return true;
		}
	public static Student[] displayStudentInfo()
	{
		Student[] d1 =null;
		return d1;
	}
		
}