package org.anudip.model;

public enum Gender {
	
	Male,Female,TRANSGENDER;

}
