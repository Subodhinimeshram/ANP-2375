package question1.main;
import java.util.Scanner;

import javax.naming.InvalidNameException;

public class Main {

    public static void main(String[] args) throws InvalidNameException {

        Scanner sc = new Scanner(System.in);
        while(true) {
            System.out.println("Enter your firstname and lastname");
            String fullName = sc.nextLine().trim();
            String nameArray[] = fullName.split(" ");
         
            if (nameArray.length != 2) {
                throw new InvalidNameException(fullName);
            }
            String name = fullName.toUpperCase();
          
            for (int i = 0; i < name.length(); i++) {
                // space
                if (name.charAt(i) == ' ') {
                    continue;
                }

                if (name.charAt(i) >=
                        'A' && name.charAt(i) <= 'Z') {
                    continue;
                } else {
                    throw new InvalidNameException(fullName);
                }
            }

            System.out.println(fullName + "It is a valid name");
            System.out.println("do you want to continue (yes/no): " );
            String decision = sc.nextLine().toUpperCase();
         
            if(decision.equals("NO")){
                break;
            }

        }


    }
}