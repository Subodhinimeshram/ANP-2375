package org.practicaltest.model;

public  class Student implements Comparable<Student> {
	
	int  studentId;
	int  studentRollNo;
	String StudentName;

	public Student()
	{
		studentId=123;
		studentRollNo=1;
		StudentName="XYZ";
	}
	public Student(int a1,int a2,String a3)
	{
		studentId=a1;
		studentRollNo=a2;
		StudentName=a3;
	}

	public int getStudentId() {
		return studentId;
	}
	public void setStudentId(int studentId) {
		this.studentId = studentId;
	}
	public int getStudentRollNo() {
		return studentRollNo;
	}
	public void setStudentRollNo(int studentRollNo) {
		this.studentRollNo = studentRollNo;
	}
	public String getStudentName() {
		return StudentName;
	}
	public void setStudentName(String studentName) {
		StudentName = studentName;
	}
	
    public String toString() {
	
	return "Student [studentId="+studentId + ",studentRollNo=" + studentRollNo + ", studentName=" + StudentName + "]";
	}
    @Override
	public int compareTo(Student obj) {
		int val=0;
		return  val;
	}
	
	

}