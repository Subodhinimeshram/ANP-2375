package org.anudip.exception;

public class StudentValidationException extends RuntimeException{
	public StudentValidationException() {
		super();
	}
	public StudentValidationException(String exceptionMessage) {
		super(exceptionMessage);
	}

}
