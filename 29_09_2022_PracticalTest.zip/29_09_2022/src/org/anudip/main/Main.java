package org.anudip.main;

import java.time.LocalDate;
import org.anudip.model.Gender;
import org.anudip.model.Student;
import org.anudip.view.StudentView;

public class Main {
	
	public static void main(String args[]) {
		//Student s1=new Student();
		//Student s2=new Student(1,"AAA",Gender.male,LocalDate.now());
		StudentView studentView=new StudentView();
		studentView.acceptStudentDetails();
	}
	

}
