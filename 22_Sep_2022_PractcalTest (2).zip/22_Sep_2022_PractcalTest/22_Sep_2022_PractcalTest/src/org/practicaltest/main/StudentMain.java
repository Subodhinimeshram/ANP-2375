package org.practicaltest.main;

import java.util.Scanner;

import org.practicaltest.model.Student;
import org.practicaltest.view.StudentView;

public class StudentMain 
{
		static Scanner p1=new Scanner(System.in);
		static void displaySubMenu()
		{
			System.out.println("1. Add Students Information :");
			System.out.println("2.Display Students Information :");
			System.out.println("Enter your Choice");
			int Choice=p1.nextInt();
			switch(Choice)
			{
			case 1:
				if(StudentView.AddStudentInfo());
				
				     System.out.println("1. StudentInformation Added Succeefully");
				       break;
			case 2:
				      Student[] student=(Student[]) StudentView.displayStudentsInfo();
				for(Student localStudent1:student)
				{
					if(localStudent1!=null)
						System.out.println(localStudent1);
					else 
						break;
				}
				break;
					default:
						System.out.println("Not a valid Input");
				}
			}
		public static void main(String[] args)
		{
			int choice;
			do
			{
				System.out.println("1. Start Applicaion");
				System.out.println("2.Stop Application");
				System.out.println("Enter our Choice");
				choice=p1.nextInt();
				
				switch(choice)
				{
				case 1:
					displaySubMenu();
					break;
				case 2:
					System.exit(0);
					break;
					default:
						System.out.println("Not a valid input");
				}
			}
			while(true);		
	}
}

