package org.practicaltest.view;
import java.util.Scanner;

import org.practicaltest.model.Student;
import org.practicaltest.service.StudentService;


public class StudentView 
{
	static Scanner s1=new Scanner(System.in);
	public static boolean AddStudentInfo()
	{
		for(int i=0;i<2;i++)
		{
			
		
		System.out.println("Enter Students Information Here:");
		System.out.println("Enter StudentId :");
		int a1=s1.nextInt();
		System.out.println("Enter Student Roll No:");
		int a2=s1.nextInt();
		s1.nextLine();
		System.out.println("Enter Student Name:");
		String a3=s1.nextLine();
		
		Student student=new Student(a1,a2,a3);
		StudentService.AddStudentInfo(student);
		}
		return true;
	}
	
	public static Student[] displayStudentsInfo()
	{
		return StudentService.displayStudentsInfo();
	}
	

}
